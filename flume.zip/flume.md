---
title: flume
date: 2023-06-19 08:45:46
tags:
---
# 十一、Flume常用组件详解：channel
## 1. memory channel
### （1）特性
事件被存储在实现配置好容量的内存（队列）中。速度快，但可靠性较低，有可能会丢失数据
channel是agent中用来缓存event的repository（池，仓库）
channel跟事务控制有极大关系；
channel 有容量大小、可靠性级别、事务容量等特性；
### （2）配置示例
a1.channels = c1
a1.channels.c1.type = memory
a1.channels.c1.capacity = 10000
a1.channels.c1.transactionCapacity = 10000
a1.channels.c1.byteCapacityBufferPercentage = 20
a1.channels.c1.byteCapacity = 800000
## 2．file channel
### （1）特性
event被缓存在本地磁盘文件中
可靠性高，不会丢失
但在极端情况下可能会重复数据
### （2）配置示例
a1.sources = r1
a1.sources.r1.type = TAILDIR
a1.sources.r1.channels = c1
a1.sources.r1.positionFile = /root/taildir_chkp/taildir_position.json
a1.sources.r1.filegroups = f1
a1.sources.r1.filegroups.f1 = /root/weblog/access.log
a1.sources.r1.fileHeader = true
a1.sources.ri.maxBatchCount = 1000
a1.channels = c1
a1.channels.c1.type = file
a1.channels.c1.capacity = 1000000
a1.channels.c1.transactionCapacity = 100
a1.channels.c1.checkpointDir = /root/flume_chkp
a1.channels.c1.dataDirs = /root/flume_data
a1.sinks = k1
a1.sinks.k1.type = logger
a1.sinks.k1.channel = c
# 十二、Flume常用组件详解：sink
## 1. hdfs sink
### （1）特性
sink是从channel中获取、移除数据，并输出到下游（可能是下一级agent，也可能是最终目标存储系统）
sink从channel中取并移除event
数据被最终发往hdfs
可以生成text文件或 sequence 文件，而且支持压缩；
支持生成文件的周期性roll机制：基于文件size，或者时间间隔，或者event数量；
目标路径，可以使用动态通配符替换，比如用%D代表当前日期；
当然，它也能从event的header中，取到一些标记来作为通配符替换；
header:{type=acb}
/weblog/%{type}/%D/ 就会被替换成： /weblog/abc/19-06-09/
### （2）配置示例
#定义
a1.sources = r1
a1.sinks = k1
a1.channels = c1
#source
a1.sources.r1.type = exec
a1.sources.r1.command = tail -F /root/logs/a.log
a1.sources.r1.channels = c1
a1.sources.r1.interceptors = i1
a1.sources.r1.interceptors.i1.type = timestamp
#channel
a1.channels.c1.type = memory
a1.channels.c1.capacity = 100000000
#sink
a1.sinks.k1.channel = c1
a1.sinks.k1.type = hdfs
a1.sinks.k1.hdfs.path = hdfs://node1:8020/logdata/%{b}/%Y-%m-%d/%H-%M
a1.sinks.k1.hdfs.round = true
a1.sinks.k1.hdfs.roundValue = 10
a1.sinks.k1.hdfs.roundUnit = minute
a1.sinks.k1.hdfs.filePrefix = doit_
a1.sinks.k1.hdfs.fileSuffix = .log.gz
a1.sinks.k1.hdfs.rollInterval = 0
a1.sinks.k1.hdfs.rollSize = 102400
a1.sinks.k1.hdfs.rollCount = 0
a1.sinks.k1.hdfs.fileType = CompressedStream
a1.sinks.k1.hdfs.codeC = gzip
a1.sinks.k1.hdfs.writeFormat = Text
## 2. avro sink
### （1）特性
avro sink用来向avro source发送avro序列化数据，这样就可以实现agent之间的级联
### （2）配置示例
级联配置，需要至少两个flume agent来演示
在C703上，配置avro sink 发送者
##c703 ##
a1.sources = s1
a1.sources.s1.type = exec
a1.sources.s1.command = tail -F /root/weblog/access.log
a1.sources.s1.channels = c1
a1.channels = c1
a1.channels.c1.type = memory
a1.sinks = k1
a1.sinks.k1.type = avro
a1.sinks.k1.channel = c1
a1.sinks.k1.hostname = c701
a1.sinks.k1.port = 4545

在C701上，配置avro source 接收者
##c701 ##
a1.sources = s1
a1.sources.s1.type = avro
a1.sources.s1.hostname = 0.0.0.0
a1.sources.s1.port = 4545
a1.sources.s1.channel = c1
a1.channels = c1
a1.channels.c1.type = memory
a1.sinks = k1
a1.sinks.k1.type = logger
a1.sinks.k1.channel = c1
# 十三、Channel选择器（channel selector）
## 1.source
source往channel中添加event
一个source可以对接多个channel
那么，source的数据如何在多个channel之间传递，就由selector来控制
配置应该挂载到source组件上
## 2．Replicating Channel Selector（复制选择器）
### （1）简介
replicating selector就是默认的选择器
### （2）使用案例
下面的配置中，c2是一个可选的channel，写入c2失败的话会被忽略，c1没有标记为可选，如果写入c1失败会导致事务的失败
#example10-channel-replicating.conf
a1.sources = r1
a1.sinks = k1 k2
a1.channels = c1 c2
a1.sources.r1.type = exec
a1.sources.r1.channels = c1 c2
a1.sources.r1.command = tail -F /export/data/flume-example-data/logdata/access.log
a1.sources.r1.batchSize = 1000
a1.sources.r1.selector.type = replicating
a1.sources.r1.selector.optional = c2
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 1000
a1.channels.c2.type = memory
a1.channels.c2.capacity = 1000
a1.channels.c2.transactionCapacity = 1000
a1.sinks.k1.channel = c1
a1.sinks.k1.type = hdfs
a1.sinks.k1.hdfs.path = hdfs://node1:8020/logdata_c1/%Y-%m-%d/%H/
a1.sinks.k1.hdfs.filePrefix = logdata_
a1.sinks.k1.hdfs.fileSuffix = .log
a1.sinks.k1.hdfs.rollInterval = 0
a1.sinks.k1.hdfs.rollSize = 268435456
a1.sinks.k1.hdfs.rollCount = 0
a1.sinks.k1.hdfs.batchSize = 1000
a1.sinks.k1.hdfs.fileType = DataStream
a1.sinks.k1.hdfs.useLocalTimeStamp = true
a1.sinks.k2.channel = c2
a1.sinks.k2.type = hdfs
a1.sinks.k2.hdfs.path = hdfs://node1:8020/logdata_c2/%Y-%m-%d/%H/
a1.sinks.k2.hdfs.filePrefix = logdata_
a1.sinks.k2.hdfs.fileSuffix = .log
a1.sinks.k2.hdfs.rollInterval = 0
a1.sinks.k2.hdfs.rollSize = 268435456
a1.sinks.k2.hdfs.rollCount = 0
a1.sinks.k2.hdfs.batchSize = 1000
a1.sinks.k2.hdfs.fileType = DataStream
a1.sinks.k2.hdfs.useLocalTimeStamp = true
![](..//flxx/1.png)
## 3. Multiplexing Channel Selector（多路选择器）
### （1）简介
multiplexing selector可以根据event中的一个指定key的value来决定这条消息会写入哪个channel，具体在选择时，需要配置一个映射关系，比如：a1.sources.r1.selector.mapping.CZ=c1 ; 就意味着header中的value为CZ的话，这条消息就会被写入c1这个channel
### （2）使用案例
#example11-channel-Multiplexing.conf
a1.sources = r1
a1.channels = c1 c2
a1.sinks = k1 k2
a1.sources.r1.type = TAILDIR
a1.sources.r1.channels = c1 c2
a1.sources.r1.positionFile = /export/data/flume-example-data/flumedata/taildir_position.json
a1.sources.r1.filegroups = g1 g2
a1.sources.r1.filegroups.g1 = /export/data/flume-example-data/weblog/web.*
a1.sources.r1.filegroups.g2 = /export/data/flume-example-data/wxlog/wx.*
a1.sources.r1.headers.g1.logtype = web
a1.sources.r1.headers.g2.logtype = wx
a1.sources.r1.selector.type = multiplexing
a1.sources.r1.selector.header = logtype
a1.sources.r1.selector.mapping.web = c1
a1.sources.r1.selector.mapping.wx = c2
a1.sources.r1.selector.default = c2
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 1000
a1.channels.c2.type = memory
a1.channels.c2.capacity = 1000
a1.channels.c2.transactionCapacity = 1000
a1.sinks.k1.channel = c1
a1.sinks.k1.type = hdfs
a1.sinks.k1.hdfs.path = hdfs://node1:8020/%{logtype}/%Y-%m-%d/%H/
a1.sinks.k1.hdfs.filePrefix = logdata_
a1.sinks.k1.hdfs.fileSuffix = .log
a1.sinks.k1.hdfs.rollInterval = 0
a1.sinks.k1.hdfs.rollSize = 268435456
a1.sinks.k1.hdfs.rollCount = 0
a1.sinks.k1.hdfs.batchSize = 1000
a1.sinks.k1.hdfs.fileType = DataStream
a1.sinks.k1.hdfs.useLocalTimeStamp = true
a1.sinks.k2.channel = c2
a1.sinks.k2.type = hdfs
a1.sinks.k2.hdfs.path = hdfs://node1:8020/%{logtype}/%Y-%m-%d/%H/
a1.sinks.k2.hdfs.filePrefix = logdata_
a1.sinks.k2.hdfs.fileSuffix = .log
a1.sinks.k2.hdfs.rollInterval = 0
a1.sinks.k2.hdfs.rollSize = 268435456
a1.sinks.k2.hdfs.rollCount = 0
a1.sinks.k2.hdfs.batchSize = 1000
a1.sinks.k2.hdfs.fileType = DataStream
a1.sinks.k2.hdfs.useLocalTimeStamp = true
![](..//flxx/2.png)
这里通过事件的header值来判断将事件发送到哪个channel，还可以配合拦截器一起使用。
# 十四、Sink处理器（sink processor）
## 1.简介
一个agent中，多个sink可以被组装到一个sink组，而数据在组内多个sink之间发送，由sink processor来决定
Sink processor在flume中有3种：
第一种： 默认的，不需要专门去配置的；相当于负载均衡，但是sink不需要创建group；
第二种： failover sink processor 自动失败切换，需要将多个sink创建成group
第三种： load_balance sink processor 负载均衡，需要将多个sink创建成group
可以将多个sink放入到一个组中，Sink处理器能够对一个组中所有的sink进行负载均衡，在一个sink出现临时错误时进行故障转移。
## 2.示例
a1.sinkgroups = g1
a1.sinkgroups.g1.sinks = k1 k2
a1.sinkgroups.g1.processor.type = failover
## 3. Default Sink Processor
默认的Sink处理器只支持单个Sink
## 4. Failover Sink Processor
### （1）简介
一组中只有优先级高的那个sink在工作，另一个是等待中
如果高优先级的sink发送数据失败，则专用低优先级的sink去工作，并且，在配置时间penalty之后，还会尝试用高优先级的去发送数据。
故障转移处理器维护了一个带有优先级的sink列表，故障转移机制将失败的sink放入到一个冷却池中，如果sink成功发送了事件，将其放入到活跃池中，sink可以设置优先级，数字越高，优先级越高，如果一个sink发送事件失败，下一个有更高优先级的sink将被用来发送事件，比如，优先级100的比优先级80的先被使用，如果没有设置优先级，按配置文件中配置的顺序决定。
### （2）示例
a1.sinkgroups = g1
a1.sinkgroups.g1.sinks = k1 k2
a1.sinkgroups.g1.processor.type = failover
##对两个sink分配不同的优先级
a1.sinkgroups.g1.processor.priority.k1 = 200
a1.sinkgroups.g1.processor.priority.k2 = 100
##主sink失败后，停用惩罚时间
a1.sinkgroups.g1.processor.maxpenalty = 5000
注：优先级高的sink如果失败，则processor会激活优先级第二的sink；
然后经过指定惩罚时间后，processor会再次尝试激活优先级高的sink。
### （3）实例
A.上游flume配置（node1）
#example12-1-sink-failover.conf
a1.sources = r1
a1.channels = c1
a1.sinks = k1 k2
a1.sources.r1.type = exec
a1.sources.r1.channels = c1
a1.sources.r1.command = tail -F /export/data/flume-example-data/logdata/access.log
a1.sources.r1.batchSize = 1000
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 1000
a1.sinks.k1.channel = c1
a1.sinks.k1.type = avro
a1.sinks.k1.hostname = node2
a1.sinks.k1.port = 44444
a1.sinks.k1.batch-size = 1000
a1.sinks.k2.channel = c1
a1.sinks.k2.type = avro
a1.sinks.k2.hostname = node3
a1.sinks.k2.port = 44444
a1.sinks.k2.batch-size = 1000
a1.sinkgroups = g1
a1.sinkgroups.g1.sinks = k1 k2
a1.sinkgroups.g1.processor.type = failover
a1.sinkgroups.g1.processor.priority.k1 = 200
a1.sinkgroups.g1.processor.priority.k2 = 100
a1.sinkgroups.g1.processor.maxpenalty = 5000
![](..//flxx/3.png)
B.下游flume配置（node3）
#example12-2-sink-failover.conf
a1.sources = r1
a1.channels = c1
a1.sinks = k1
a1.sources.r1.type = avro
a1.sources.r1.channels = c1
a1.sources.r1.bind = 0.0.0.0
a1.sources.r1.port = 44444
a1.sources.r1.threads = 10
a1.sources.r1.batchSize = 1000
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 1000
a1.sinks.k1.type = logger
a1.sinks.k1.channel = c1
![](..//flxx/4.png)
## 5. Load balancing Sink Processor
### （1）简介
允许channel中的数据在一组sink中的多个sink之间进行交替，交替策略有：
round_robin（轮询算法）
random（随机）
负载均衡处理器，可以通过轮询或者随机的方式进行负载均衡，也可以通过继承AbstractSinkSelector 自定义负载均衡
### （2）示例
a1.sinkgroups = g1
a1.sinkgroups.g1.sinks = k1 k2
a1.sinkgroups.g1.processor.type = load_balance
a1.sinkgroups.g1.processor.backoff = true
a1.sinkgroups.g1.processor.selector = round_robin
### （3）实例
A.上游flume配置（node1）
#example13-1-sink-loadbalance.conf
a1.sources = r1
a1.channels = c1
a1.sinks = k1 k2
a1.sources.r1.type = exec
a1.sources.r1.channels = c1
a1.sources.r1.command = tail -F /export/data/flume-example-data/logdata/access.log
a1.sources.r1.batchSize = 1000
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 1000
a1.sinks.k1.channel = c1
a1.sinks.k1.type = avro
a1.sinks.k1.hostname = node2
a1.sinks.k1.port = 44444
a1.sinks.k1.batch-size = 1000
a1.sinks.k2.channel = c1
a1.sinks.k2.type = avro
a1.sinks.k2.hostname = node3
a1.sinks.k2.port = 44444
a1.sinks.k2.batch-size = 1000
a1.sinkgroups = g1
a1.sinkgroups.g1.sinks = k1 k2
a1.sinkgroups.g1.processor.type = load_balance
a1.sinkgroups.g1.processor.backoff = true 
a1.sinkgroups.g1.processor.selector = round_robin
![](..//flxx/5.png)
B.下游flume配置（node3）
#example13-2-sink-loadbalance.conf
a1.sources = r1
a1.channels = c1
a1.sinks = k1
a1.sources.r1.type = avro
a1.sources.r1.channels = c1
a1.sources.r1.bind = 0.0.0.0
a1.sources.r1.port = 44444
a1.sources.r1.threads = 10
a1.sources.r1.batchSize = 1000
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 1000
a1.sinks.k1.type = logger
a1.sinks.k1.channel = c1
![](..//flxx/6.png)
# 十五、flume进阶
## 1. flume 事务机制
Delivery 保证
认识 Flume 对事件投递的可靠性保证是非常重要的，它往往是我们是否使用 Flume 来解决问题的决定因素之一。
消息投递的可靠保证有三种：
  At-least-once
At-most-once
Exactly-once
## 2.flume agent 内部机制
组件
### （1）ChannelSelector
ChannelSelector 的作用就是选出 Event 将要被发往哪个 Channel。其共有两种类型，分别是 Replicating（复制）和 Multiplexing（多路复用）。 ReplicatingSelector 会将同一个 Event 发往所有的 Channel，Multiplexing 会根据相应的原则，将不同的 Event 发往不同的 Channel。
### （2）SinkProcessor
A.SinkProcessor 共 有 三 种 类 型 ， 分 别 是 DefaultSinkProcessor 、    LoadBalancingSinkProcessor 和 FailoverSinkProcessor。
B.DefaultSinkProcessor 对应的是单个的 Sink，
LoadBalancingSinkProcessor 和 FailoverSinkProcessor 对应的是 Sink Group。
C.LoadBalancingSinkProcessor 可以实现负载均衡的功能，FailoverSinkProcessor 可以实现故障转移的功能。
## 3. flume监控及ganglia监控
### （1）flume监控
FLUME在运行时，状态是否正常，吞吐量是否正常，需要监控
Flume自身具有向外提交状态数据的功能；但是它本身没有一个完善的监控平台；
开启内置监控功能，启动时加入参数：
      -Dflume.monitoring.type=http -Dflume.monitoring.port=34545
### （2）ganglia监控
将监控数据发往ganglia进行展现
    -Dflume.monitoring.type=ganglia -Dflume.monitoring.port=34890
    Ganglia是一个通用的集群运维监控系统
### （3）Ganglia安装与配置
中心节点的安装
    - epel包的安装：yum install -y epel-release(解决不能yum安装某些安装包的问题)
- gmetad的安装：yum install -y ganglia-gmetad
- gmond的安装：yum install -y ganglia-gmond
- rrdtool的安装：yum install -y rrdtool
- httpd服务器的安装：yum install -y httpd
- ganglia-web及php安装：yum install -y ganglia-web php
被监测节点的安装
- epel包的安装：yum install -y epel-release(解决不能yum安装某些安装包的问题)
- gmond的安装：yum install -y gmond(提示找不到，感觉应该换成上面那个yum install -y ganglia-gmond)
中心节点的配置
- ganglia配置文件目录：/etc/ganglia
- rrd数据库存放目录：/var/lib/ganglia/rrds
- ganglia-web安装目录：/usr/share/ganglia
- ganglia-web配置目录：/etc/httpd/conf.d/ganglia.conf
相关配置文件修改
将ganglia-web的站点目录连接到httpd主站点目录
$  ln -s /usr/share/ganglia /var/www/html
修改httpd主站点目录下ganglia站点目录的访问权限 
将ganglia站点目录访问权限改为apache:apache，否则会报错
$  chown -R apache:apache /var/www/html/ganglia
$  chmod -R 755 /var/www/html/ganglia
修改rrd数据库存放目录访问权限 
将rrd数据库存放目录访问权限改为nobody:nobody,否则会报错
$  chown -R nobody:nobody /var/lib/ganglia/rrds
修改ganglia-web的访问权限： 
修改/etc/httpd/conf.d/ganglia.conf
Alias /ganglia /usr/share/ganglia
<Location /ganglia> 
 Require all granted
 #Require ip 10.1.2.3
 #Require host example.org
</Location>
修改dwoo下面的权限
chmod 777 /var/lib/ganglia/dwoo/compiled
chmod 777 /var/lib/ganglia/dwoo/cache
配置/etc/ganglia/gmetad.conf
data_source  "my cluster" 192.168.88.161:8649(注意是所有节点都加上，如master:8649 slave0x:8649)
setuid_username nobody
配置/etc/ganglia/gmond.conf
cluster { 
  name = "node1"
  ... 
} 
udp_send_channel { 
  # the host who gather this cluster's monitoring data and send these data   to gmetad node
  #注释掉多播模式的,以下出现这个都要注释掉
 #mcast_join = 239.2.11.71
 #添加单播模式的
 host = 192.168.88.161
 port = 8649 
} 
udp_recv_channel { 
  bind = 192.168.88.161
  port = 8649 
} 
tcp_accept_channel { 
  port = 8649 
}
被监测节点的配置
配置/etc/ganglia/gmond.conf
cluster { 
  name = "hadoop cluster"
  ... 
} 
udp_send_channel { 
  # the host who gather this cluster's monitoring data and send these data   to gmetad node
 host = 192.168.88.161  
 port = 8649 
} 
udp_recv_channel { 
  port = 8649 
} 
tcp_accept_channel { 
  port = 8649 
}
### (4)Ganglia启动
中心节点的启动
start httpd, gmetad, gmond
$ systemctl start httpd.service
$ systemctl start gmetad.service
$ systemctl start gmond.service
$ systemctl enable httpd.service
$ systemctl enable gmetad.service
$ systemctl enable gmond.service
被监测节点的启动
start gmond
$ systemctl start gmond.service
$ systemctl enable gmond.service
开启防火墙
firewall-cmd --zone=public --add-port=80/tcp --permanent
firewall-cmd --reload
### （5）添加Flume监控
修改flume-env.sh配置，添加虚拟机选项
JAVA_OPTS="-Dflume.monitoring.type=ganglia -Dflume.monitoring.hosts=192.168.88.161:8649 -Xms100m -Xmx200m"
启动flume
flume-ng agent -n a1 -c conf -f example.conf -Dflume.monitoring.type=ganglia -Dflume.monitoring.hosts=192.168.88.161:8649
## 4. flume调优
### （1）source的配置
项目中采用的是 taildir source，他的读取速度能够跟上命令行写入日志的速度，故并未做特殊的处理。
### （2）channel的配置
可选的channel配置一般有两种，一是memory channel，二是file channel。
memory channel有三个比较重要的参数需要配置：
#channel中最多缓存多少
a1.channels.c1.capacity = 5000
#channel一次最多吐给sink多少
a1.channels.c1.transactionCapacity = 2000
#event的活跃时间
a1.channels.c1.keep-alive = 10
### （3）sink的配置
可以通过压缩来节省空间和网络流量，但是会增加cpu的消耗。
batch：size越大性能越好，但是太大会影响时效性，一般batch size和源数据端的大小相同。
### （4）java内存的配置
export JAVA_OPTS="-Xms512m -Xmx2048m"
主要涉及Xms和Xmx两个参数，可以根据实际的服务器的内存大小进行设计。
### （5）OS内核参数的配置
如果单台服务器启动的flume agent过多的话，默认的内核参数设置偏小，需要调整。（待补充，暂时还未涉及）。
# 十六、使用Flume导入数据到HDFS
创建hdfs.conf
#定义agent名称为a1
#设置3个组件的名称
a1.sources = r1
a1.sinks = k1
a1.channels = c1
#配置source类型为NetCat,监听地址为本机，端口为44444
a1.sources.r1.type = netcat
a1.sources.r1.bind = localhost
a1.sources.r1.port = 44444
#配置sink类型为hdfs
a1.sinks.k1.type = hdfs
a1.sinks.k1.hdfs.path = hdfs://node01:9000/user/flume/logs
a1.sinks.k1.hdfs.fileType = DataStream
#配置channel类型为内存，内存队列最大容量为1000，一个事务中从source接收的Events数量或者发送给sink的Events数量最大为100
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 100
#将source和sink绑定到channel上
a1.sources.r1.channels = c1
a1.sinks.k1.channel = c1
启动flume
bin/flume-ng agent --conf conf/ --conf-file conf/hdfs.conf -Dfile.root.logger=debug,info,console --name hdfs
![](..//flxx/7.png)
在后台查看
hadoop fs -cat /user/flume/messages/flume-.1578835130630
# 十七、Flume SDK
## 1. 自定义Source
### （1）添加MySource
package com.itheima.flume.source;
import org.apache.flume.Context;
import org.apache.flume.Event;
import org.apache.flume.EventDeliveryException;
import org.apache.flume.PollableSource;
import org.apache.flume.conf.Configurable;
import org.apache.flume.event.SimpleEvent;
import org.apache.flume.source.AbstractSource;
public class MySource extends AbstractSource implements Configurable, PollableSource {
    // 处理数据
    public Status process() throws EventDeliveryException {
        Status status = null;
        try {
            // 接收新数据
            for (int i = 0; i < 10; i++) {
                Event e = new SimpleEvent();
                e.setBody(("data:"+i).getBytes());
                // 将数据存储到与Source关联的Channel中
                getChannelProcessor().processEvent(e);
                status = Status.READY;
            }
            Thread.sleep(5000);
        } catch (Throwable t) {
            // 打印日志
            status = Status.BACKOFF;
            // 抛出异常
            if (t instanceof Error) {
                throw (Error)t;
            }
        } finally {
        }
        return status;
    }
    public long getBackOffSleepIncrement() {
        return 0;
    }
    public long getMaxBackOffSleepInterval() {
        return 0;
    }
    public void configure(Context context) {
    }
}
### (2)添加mySourceAgent.conf
#定义agent名称为a1
#设置3个组件的名称
a1.sources = r1
a1.sinks = k1
a1.channels = c1
#配置source类型为mysource
a1.sources.r1.type = com.itheima.flume.source.MySource
#配置sink类型为Logger
a1.sinks.k1.type = logger
#配置channel类型为内存，内存队列最大容量为1000，一个事务中从source接收的Events数量或者发送给sink的Events数量最大为100
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 100
#将source和sink绑定到channel上
a1.sources.r1.channels = c1
a1.sinks.k1.channel = c1
启动Flume
flume-ng agent -n a1 -c conf -f mySourceAgent.conf
![](..//flxx/8.png)
## 2. 自定义Sink
### （1）添加MySink，可以参考LoggerSink
package com.itheima.flume.sink;
import org.apache.flume.*;
import org.apache.flume.conf.Configurable;
import org.apache.flume.sink.AbstractSink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class MySink extends AbstractSink implements Configurable {
    private static final Logger logger = LoggerFactory
            .getLogger(MySink.class);
    public Status process() throws EventDeliveryException {
        Status status = null;
        // 开启事务
        Channel ch = getChannel();
        Transaction txn = ch.getTransaction();
        try {
            txn.begin();
            // 从channel中获取数据
            Event event = ch.take();
            if(event==null){
                status = Status.BACKOFF;
            }
            // 将事件发送到外部存储
            // storeSomeData(e);
            // 打印事件
            logger.info(new String(event.getBody()));
            // 提交事务
            txn.commit();
            status = Status.READY;
        } catch (Throwable t) {
            txn.rollback();
            // 打印异常日志
            status = Status.BACKOFF;
            // 抛出异常
            if (t instanceof Error) {
                throw (Error)t;
            }
        }finally {
            txn.close();
        }
        return status;
    }
    public void configure(Context context) {
    }
}
### （2）修改上面的mySourceAgent.conf
#定义agent名称为a1
#设置3个组件的名称
a1.sources = r1
a1.sinks = k1
a1.channels = c1
#配置source类型为mysource
a1.sources.r1.type = com.itheima.flume.source.MySource
#配置sink类型为MySink
a1.sinks.k1.type = com.itheima.flume.sink.MySink
#配置channel类型为内存，内存队列最大容量为1000，一个事务中从source接收的Events数量或者发送给sink的Events数量最大为100
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 100
#将source和sink绑定到channel上
a1.sources.r1.channels = c1
a1.sinks.k1.channel = c1
# 十八、Flume 综合实战案例
## 1.案例场景
A、B、C等日志服务机器实时生产日志，日志的内容分为多种类型：
  APP端用户行为日志
  微信小程序端用户行为日志
  PC端用户行为日志
## 2. 实现思路
1. 每台日志服务器上部署一个flume agent - - -> 上游，每个agent配置2个source对应2类数据
2. 上游的agent在采集数据时，添加一个header，指定数据的类别
3. 上游的agent要配置两个avro sink，各自对接一个下级的agent
4. 上游还要配置sink processor，fail over sink processor，控制两个sink中只有一个avro sink在工作，如果失败再切换到另一个avro sink
5. 上游还要配置字段加密拦截器
6. 下游配置两个flume agent，使用avro source接收数据
7. 下游的hdfs sink，目录配置使用动态通配符，取到event中的类别header，以便于将不同类别数据写入不同hdfs目录
## 3.操作步骤
### （1）准备一个mysql服务器，并创建一个库：realtimedw
![](..//flxx/9.png)
### （2）将realtimedw.sql这个脚本，导入到realtimedw库中
![](..//flxx/10.png)
### （3）将t_md_areas.sql这个脚本，导入到realtimedw库中
![](..//flxx/11.png)
### （4）准备其他数据文件目录
新建目录
![](..//flxx/12.png)
### （5）修改jar包中的配置文件
log_gen_app.jar包中的配置文件修改
A.other.properties
#logger,kafka
sink.type=logger
#roll console dayroll
logger.type=dayroll
initdata.releasechannel=/export/data/flume-example-data/loginit/releasechannel.txt
initdata.phoneinfo=/export/data/flume-example-data/loginit/phoneinfo.txt
initdata.eventIds=/export/data/flume-example-data/loginit/eventIds.txt
init.user.area=/export/data/flume-example-data/loginit/area.txt
db.url=jdbc:mysql://127.0.0.1:3306/realtimedw?useUnicode=true&characterEncoding=utf8&useSSL=false
db.user=root
db.password=hadoop
#max concurrent accessor amount
online.max.num=1000
B.log4j.properties
log4j.rootLogger=INFO,trace
log4j.appender.trace=org.apache.log4j.ConsoleAppender
log4j.appender.trace.Threshold=DEBUG
log4j.appender.trace.ImmediateFlush=true
log4j.appender.trace.Target=System.out
log4j.appender.trace.layout=org.apache.log4j.PatternLayout
log4j.appender.trace.layout.ConversionPattern=[%-5p] %d(%r) --> [%t] %l: %m %x %n
log4j.logger.console = INFO,console
log4j.additivity.console=false
log4j.appender.console=org.apache.log4j.ConsoleAppender
log4j.appender.console.Threshold=DEBUG
log4j.appender.console.ImmediateFlush=true
log4j.appender.console.Target=System.out
log4j.appender.console.layout=org.apache.log4j.PatternLayout
log4j.appender.console.layout.ConversionPattern=%m%n
log4j.logger.dayroll = INFO,DailyRolling
log4j.additivity.dayroll=false
log4j.appender.DailyRolling=org.apache.log4j.DailyRollingFileAppender
log4j.appender.DailyRolling.File=/export/data/flume-example-data/gen_logdata/event_log_app
log4j.appender.DailyRolling.DatePattern=yyyy-MM-dd'.log'
log4j.appender.DailyRolling.layout=org.apache.log4j.PatternLayout
log4j.appender.DailyRolling.layout.ConversionPattern=%m%n

log_gen_wx.jar包中的配置文件修改
A.other.properties与上文一致
B.log4j.properties 其中一行修改为
log4j.appender.DailyRolling.File=/export/data/flume-example-data/gen_logdata/event_log_wx
### （6）上传jar包，执行启动命令
在/export/data/flume-example-data/loginit 中添加shell文件用以启动日志生成器
vim genapplog.sh
java -Xss102400k -cp log_gen_app.jar cn.doitedu.loggen.entry.GenAppLog 1 > /dev/null 2>&1 &
![](..//flxx/13.png)
vim genwxlog.sh
java -Xss102400k -cp log_gen_wx.jar cn.doitedu.loggen.entry.GenWxAppLog 1 > /dev/null 2>&1 &
![](..//14.png)
sh genapplog.sh
sh genwxlog.sh
### （7）查看日志文件生成成果
![](..//flxx/15.png)
![](..//flxx/16.png)
## 4.配置文件
### （1）上游配置文件：(node1)
#example14-1-Comprehensive-practical.conf
a1.sources = r1
a1.channels = c1
a1.sinks = k1 k2
a1.sources.r1.type = TAILDIR
a1.sources.r1.channels = c1
a1.sources.r1.positionFile = /export/data/flume-example-data/flumedata/taildir_position.json
a1.sources.r1.filegroups = g1
a1.sources.r1.filegroups.g1 =  /export/data/flume-example-data/gen_logdata/event_.*
a1.sources.r1.batchSize = 1000
a1.sources.r1.interceptors = i1 i2 i3
a1.sources.r1.interceptors.i1.type = ccjz.rgzn.flume.EncryptSpecifiedFieldInterceptor$EncryptInterceptorBuilder
a1.sources.r1.interceptors.i1.toEncryFieldName = account
a1.sources.r1.interceptors.i2.type = ccjz.rgzn.flume.EventTimeStampExtractInterceptor$EventTimestampInterceptorBuilder
a1.sources.r1.interceptors.i2.tsFiledName = timeStamp
a1.sources.r1.interceptors.i2.keyName = timestamp
#拥有openid的是wx小程序用户日志
a1.sources.r1.interceptors.i3.type = ccjz.rgzn.flume.LogTypeInterceptor$LogTypeInterceptorBuilder
a1.sources.r1.interceptors.i3.flag.fieldname = openid
a1.sources.r1.interceptors.i3.headerKey = logtype
a1.channels.c1.type = file
a1.channels.c1.checkpointDir =  /export/data/flume-example-data/flumedata/checkpoint
a1.channels.c1.dataDirs =  /export/data/flume-example-data/flumedata/data
a1.channels.c1.transactionCapacity = 2000
a1.sinks.k1.channel = c1
a1.sinks.k1.type = avro
a1.sinks.k1.hostname = node2
a1.sinks.k1.port = 44444
a1.sinks.k1.batch-size = 1000
a1.sinks.k2.channel = c1
a1.sinks.k2.type = avro
a1.sinks.k2.hostname = node3
a1.sinks.k2.port = 44444
a1.sinks.k2.batch-size = 1000
a1.sinkgroups = g1
a1.sinkgroups.g1.sinks = k1 k2
a1.sinkgroups.g1.processor.type = failover
a1.sinkgroups.g1.processor.priority.k1 = 200
a1.sinkgroups.g1.processor.priority.k2 = 100
a1.sinkgroups.g1.processor.maxpenalty = 5000
![](..//flxx/17.png)
### （2）下游配置文件：(node3)
#example14-2-Comprehensive-practical.conf
a1.sources = r1
a1.channels = c1
a1.sinks = k1
a1.sources.r1.type = avro
a1.sources.r1.channels = c1
a1.sources.r1.bind = 0.0.0.0
a1.sources.r1.port = 44444
a1.sources.r1.threads = 10
a1.sources.r1.batchSize = 1000
a1.channels.c1.type = file
a1.channels.c1.checkpointDir =  /export/data/flume-example-data/flumedata_2/checkpoint
a1.channels.c1.dataDirs =  /export/data/flume-example-data/flumedata_2/data
a1.channels.c1.transactionCapacity = 2000
a1.sinks.k1.channel = c1
a1.sinks.k1.type = hdfs
a1.sinks.k1.hdfs.path = hdfs://node1:8020/gen_logdata/%{logtype}/%Y-%m-%d/
a1.sinks.k1.hdfs.filePrefix = logdata_
a1.sinks.k1.hdfs.fileSuffix = .log
a1.sinks.k1.hdfs.rollInterval = 300
a1.sinks.k1.hdfs.rollSize = 268435456
a1.sinks.k1.hdfs.rollCount = 0
a1.sinks.k1.hdfs.batchSize = 1000
a1.sinks.k1.hdfs.codeC = gzip
a1.sinks.k1.hdfs.fileType = CompressedStream
![](..//flxx/18.png)
## 5.启动测试
![](..//flxx/19.png)
![](..//flxx/20.png)
![](..//flxx/21.png)
![](..//flxx/22.png)
![](..//flxx/23.png)
![](..//flxx/24.png)